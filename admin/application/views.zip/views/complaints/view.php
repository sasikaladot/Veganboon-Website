<!-- data tables -->
<link href="<?=base_url();?>/assets/datatables/plugins/bootstrap/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<?php $this->load->view('includes/header');?>
		<!-- start page container -->
		<div class="page-container">
			<!-- start sidebar menu -->
			<?php $this->load->view('includes/sidebar');?>
			<!-- start page content -->
			<div class="page-content-wrapper">
				<div class="page-content">
					<div class="page-bar col-md-9" style="margin:0px auto;padding:0">
						<div class="page-title-breadcrumb">
							<div class=" pull-left">
								<div class="page-title">Complaint View</div>
							</div>
							<ol class="breadcrumb page-breadcrumb pull-right">
								<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="<?=base_url();?>/dashboard">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li>&nbsp;<a class="parent-item" href="<?=base_url();?>/complaints">Complaint</a>&nbsp;<i class="fa fa-angle-right"></i>
								</li>
								<li class="active">View Complaint</li>
							</ol>
						</div>
					</div>
					<?php $this->load->view('includes/msg');?>
					<div class="row">
						<div class="col-md-9" style="margin:0px auto;">
							
							<?php
							if(isset($viewComplaint)&& $viewComplaint->num_rows()>0)
							{
								$view=$viewComplaint->row();
								
								$id=$view->id;
								$name=$view->name;
								$icnumber=$view->icnumber;
								$contactnumber=$view->contactnumber;
								$createdAt=$view->createdAt;
								$newDate = date("d-m-Y", strtotime($createdAt));
								$complaintStatus=$view->complaintStatus;
								$description=$view->description;
								if($complaintStatus==1)
								{
									$status="Pending";
								}
								elseif($complaintStatus==2)
								{
									$status="Process";
								}
								elseif($complaintStatus==3)
								{
									$status="Completed";
								}
							}
										
							?>
							<!-- BEGIN PROFILE SIDEBAR -->
								<div class="card card-topline-aqua">
									<div class="card-body no-padding height-9">
										<div class="profile-usertitle">
											<div class="profile-usertitle-name"><?=$name;?></div>
											<div class="profile-usertitle-job"> <?=$status;?> </div>
										</div>
										
										<hr>
										<div class="row">
											<div class="col-md-4 col-xs-6 b-r"> <strong>Date</strong>
												<br>
												<p class="text-muted"><?=$newDate;?></p>
											</div>
											<div class="col-md-4 col-xs-6 b-r"> <strong>IC NUmber</strong>
												<br>
												<p class="text-muted"><?=$icnumber;?></p>
											</div>
											<div class="col-md-4 col-xs-6 b-r"> <strong>Contact NUmber</strong>
												<br>
												<p class="text-muted"><?=$contactnumber;?></p>
											</div>
										</div>
										<div class="row">
											<div class="col-md-12 col-xs-6 b-r"> <strong>Description</strong>
												<br>
												<p class="text-muted"><?=$description;?></p>
											</div>
											
										</div>
										<!-- END SIDEBAR USER TITLE -->
										<!-- SIDEBAR BUTTONS -->
										
										<!-- END SIDEBAR BUTTONS -->
									</div>
								</div>
								
							<!-- END PROFILE CONTENT -->
							<!-- END BEGIN PROFILE SIDEBAR -->
						</div>
					</div>
				</div>
			</div>
	</div>
	
<?php $this->load->view('includes/footer');?>
			<!-- data tables -->
	<script src="<?=base_url();?>/assets/datatables/jquery.dataTables.min.js"></script>
	<script src="<?=base_url();?>/assets/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js"></script>
	<script src="<?=base_url();?>/assets/table_data.js"></script>
		