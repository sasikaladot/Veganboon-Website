<!-- start footer -->
		<div class="page-footer">
			<div class="page-footer-inner"> 2023 &copy; Created By 
				<a href="" target="_top" class="makerCss">Dowings</a>
			</div>
			<div class="scroll-to-top">
				<i class="icon-arrow-up"></i>
			</div>
		</div>
		<!-- end footer -->
	</div>
	<!-- start js include path -->
	<script src="<?=base_url();?>/assets/jquery.min.js"></script>
	<script src="<?=base_url();?>/assets/popper/popper.js"></script>
	<script src="<?=base_url();?>/assets/jquery.blockui.min.js"></script>
	<script src="<?=base_url();?>/assets/jquery.slimscroll.js"></script>
	
	<!-- bootstrap -->
	<script src="<?=base_url();?>/assets/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?=base_url();?>/assets/bootstrap-switch/js/bootstrap-switch.min.js"></script>
	<!-- counterup -->
	<script src="<?=base_url();?>/assets/counterup/jquery.waypoints.min.js"></script>
	<script src="<?=base_url();?>/assets/counterup/jquery.counterup.min.js"></script>
	<!-- Common js-->
	<script src="<?=base_url();?>/assets/app.js"></script>
	<script src="<?=base_url();?>/assets/layout.js"></script>
	<script src="<?=base_url();?>/assets/theme-color.js"></script>
	<!-- material -->
	<script src="<?=base_url();?>/assets/material/material.min.js"></script>
	<!-- chart js -->
	<script src="<?=base_url();?>/assets/chart-js/Chart.bundle.js"></script>
	<script src="<?=base_url();?>/assets/chart-js/utils.js"></script>
	<script src="<?=base_url();?>/assets/chart-js/home-data.js"></script>
	<script src="<?=base_url();?>assets/jquery.cookie.min.js"></script>
	<!-- end js include path -->
</body>


<!-- Mirrored from radixtouch.in/templates/admin/redstar/source/light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Aug 2019 14:04:55 GMT -->
</html>